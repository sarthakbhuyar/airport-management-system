// Passenger Management Functions
async function loadPassengersData() {
    try {
        const response = await fetch('/api/passengers?populate=bookings');
        const passengers = await response.json();
        
        const tableBody = document.querySelector('#passengers-table tbody');
        tableBody.innerHTML = '';
        
        passengers.forEach(passenger => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${passenger.firstName} ${passenger.lastName}</td>
                <td>${passenger.age}</td>
                <td>${passenger.governmentIdType}</td>
                <td>${passenger.contactNumber}</td>
                <td>
                    ${passenger.bookings ? passenger.bookings.length : 0} bookings
                    ${passenger.bookings && passenger.bookings.some(b => b.status === 'Pending') ? 
                        '<span class="status-badge status-pending">Pending</span>' : ''}
                </td>
                <td>
                    <button class="view-btn" data-id="${passenger._id}">View</button>
                    <button class="edit-btn" data-id="${passenger._id}">Edit</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
        
        // Add event listeners
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => viewPassengerDetails(e.target.getAttribute('data-id')));
        });
        
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => editPassenger(e.target.getAttribute('data-id')));
        });
        
    } catch (error) {
        console.error('Error loading passengers data:', error);
        alert('Failed to load passengers. Please try again.');
    }
}

async function loadFlightsForBooking() {
    try {
        const travelDate = document.getElementById('travelDate').value;
        if (!travelDate) return;
        
        const response = await fetch(`/api/flights?date=${travelDate}`);
        const flights = await response.json();
        
        const flightSelect = document.getElementById('flightSelect');
        flightSelect.innerHTML = '<option value="">Select Flight</option>';
        
        flights.forEach(flight => {
            if (flight.availableSeats > 0) {
                const option = document.createElement('option');
                option.value = flight._id;
                option.textContent = `${flight.flightNumber} - ${flight.airline} (${flight.departureAirport} to ${flight.arrivalAirport}) - ${new Date(flight.departureTime).toLocaleTimeString()} - Seats: ${flight.availableSeats}`;
                flightSelect.appendChild(option);
            }
        });
        
    } catch (error) {
        console.error('Error loading flights:', error);
        document.getElementById('flightSelect').innerHTML = '<option value="">Error loading flights</option>';
    }
}

async function calculateFare() {
    const adults = parseInt(document.getElementById('adults').value) || 0;
    const children = parseInt(document.getElementById('children').value) || 0;
    const infants = parseInt(document.getElementById('infants').value) || 0;
    const flightId = document.getElementById('flightSelect').value;
    
    if (!flightId) {
        alert('Please select a flight first');
        return;
    }
    
    try {
        const response = await fetch(`/api/flights/${flightId}/fare`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                adults,
                children,
                infants
            })
        });
        
        if (!response.ok) throw new Error('Failed to calculate fare');
        
        const data = await response.json();
        document.getElementById('total-fare').textContent = `$${data.totalAmount}`;
        document.getElementById('fare-display').style.display = 'block';
        document.getElementById('book-ticket-btn').disabled = false;
        
        // Load seat map
        await loadSeatMap(flightId);
        
    } catch (error) {
        console.error('Error calculating fare:', error);
        alert('Failed to calculate fare. Please try again.');
    }
}

async function loadSeatMap(flightId) {
    try {
        const response = await fetch(`/api/flights/${flightId}/seats`);
        const seats = await response.json();
        
        const seatMap = document.getElementById('seat-map');
        seatMap.innerHTML = '';
        
        seats.forEach(seat => {
            const seatElement = document.createElement('div');
            seatElement.className = `seat ${seat.status === 'available' ? '' : 'booked'}`;
            seatElement.textContent = seat.number;
            seatElement.dataset.seatNumber = seat.number;
            seatElement.dataset.status = seat.status;
            
            if (seat.status === 'available') {
                seatElement.addEventListener('click', () => {
                    seatElement.classList.toggle('selected');
                });
            }
            
            seatMap.appendChild(seatElement);
        });
        
        document.getElementById('seat-selection').style.display = 'block';
        
    } catch (error) {
        console.error('Error loading seat map:', error);
        document.getElementById('seat-selection').style.display = 'none';
    }
}

async function bookTicket(event) {
    event.preventDefault();
    
    // Collect form data
    const passengerData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        age: document.getElementById('age').value,
        gender: document.getElementById('gender').value,
        governmentIdType: document.getElementById('idType').value,
        governmentIdNumber: document.getElementById('idNumber').value,
        email: document.getElementById('email').value,
        contactNumber: document.getElementById('contact').value
    };
    
    const bookingData = {
        flight: document.getElementById('flightSelect').value,
        travelDate: document.getElementById('travelDate').value,
        adults: parseInt(document.getElementById('adults').value),
        children: parseInt(document.getElementById('children').value),
        infants: parseInt(document.getElementById('infants').value),
        totalAmount: parseFloat(document.getElementById('total-fare').textContent.replace('$', '')),
        selectedSeats: Array.from(document.querySelectorAll('.seat.selected')).map(seat => ({
            seatNumber: seat.dataset.seatNumber,
            passengerName: passengerData.firstName + ' ' + passengerData.lastName,
            passengerAge: passengerData.age,
            passengerGender: passengerData.gender
        }))
    };
    
    try {
        // First create/update passenger
        const passengerResponse = await fetch('/api/passengers', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(passengerData)
        });
        
        if (!passengerResponse.ok) throw new Error('Failed to save passenger');
        
        const passenger = await passengerResponse.json();
        
        // Then create booking
        bookingData.passenger = passenger._id;
        
        const bookingResponse = await fetch('/api/bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(bookingData)
        });
        
        if (!bookingResponse.ok) throw new Error('Failed to create booking');
        
        const booking = await bookingResponse.json();
        
        // Show confirmation
        showConfirmation(booking, passenger);
        
        // Refresh passengers list
        loadPassengersData();
        
    } catch (error) {
        console.error('Error booking ticket:', error);
        alert('Failed to book ticket. Please try again.');
    }
}

function showConfirmation(booking, passenger) {
    const modal = document.getElementById('confirmation-modal');
    const details = document.getElementById('confirmation-details');
    
    details.innerHTML = `
        <p><strong>Booking Reference:</strong> ${booking._id}</p>
        <p><strong>Passenger:</strong> ${passenger.firstName} ${passenger.lastName}</p>
        <p><strong>Flight:</strong> ${booking.flight.flightNumber}</p>
        <p><strong>Travel Date:</strong> ${new Date(booking.travelDate).toLocaleDateString()}</p>
        <p><strong>Seats:</strong> ${booking.seats.map(s => s.seatNumber).join(', ')}</p>
        <p><strong>Total Amount:</strong> $${booking.ticketDetails.totalAmount}</p>
        <p><strong>Status:</strong> <span class="status-badge ${booking.status === 'Confirmed' ? 'status-confirmed' : 'status-pending'}">${booking.status}</span></p>
    `;
    
    modal.style.display = 'block';
    
    // Close modal when clicking X
    document.querySelector('.close-modal').onclick = function() {
        modal.style.display = 'none';
    };
    
    // Print ticket button
    document.getElementById('print-ticket').onclick = function() {
        window.print();
    };
    
    // New booking button
    document.getElementById('new-booking').onclick = function() {
        modal.style.display = 'none';
        document.getElementById('ticket-booking-form').reset();
        document.getElementById('fare-display').style.display = 'none';
        document.getElementById('seat-selection').style.display = 'none';
        document.getElementById('book-ticket-btn').disabled = true;
    };
}

// Event Listeners for Passenger Section
document.getElementById('travelDate').addEventListener('change', loadFlightsForBooking);
document.getElementById('calculate-btn').addEventListener('click', calculateFare);
document.getElementById('ticket-booking-form').addEventListener('submit', bookTicket);
document.getElementById('refresh-passengers').addEventListener('click', loadPassengersData);
document.getElementById('passenger-search').addEventListener('input', function() {
    // Implement search functionality
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll('#passengers-table tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
});

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Load current date as default
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('travelDate').value = today;
    document.getElementById('travelDate').min = today;
    
    // Load flights for today
    loadFlightsForBooking();
});