const express = require('express');
const router = express.Router();
const Passenger = require('../models/passenger');
const Booking = require('../models/booking');

// Get all passengers with their bookings
router.get('/', async (req, res) => {
    try {
        const query = req.query.populate === 'bookings' ? 
            Passenger.find().populate('bookings') : 
            Passenger.find();
            
        const passengers = await query.exec();
        res.json(passengers);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Create or update passenger
router.post('/', async (req, res) => {
    try {
        // Check if passenger exists by email
        let passenger = await Passenger.findOne({ email: req.body.email });
        
        if (passenger) {
            // Update existing passenger
            Object.assign(passenger, req.body);
            passenger.updatedAt = new Date();
        } else {
            // Create new passenger
            passenger = new Passenger(req.body);
        }
        
        const savedPassenger = await passenger.save();
        res.status(201).json(savedPassenger);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Other existing routes...

module.exports = router;