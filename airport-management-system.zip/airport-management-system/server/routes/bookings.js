const express = require('express');
const router = express.Router();
const Booking = require('../models/booking');
const Flight = require('../models/flight');
const Passenger = require('../models/passenger');

// Create booking
router.post('/', async (req, res) => {
    try {
        // Validate flight
        const flight = await Flight.findById(req.body.flight);
        if (!flight) {
            return res.status(400).json({ message: 'Flight not found' });
        }
        
        // Validate seats are available
        if (req.body.selectedSeats.length === 0) {
            return res.status(400).json({ message: 'No seats selected' });
        }
        
        // Check each seat availability
        const seatCheck = await Promise.all(
            req.body.selectedSeats.map(seat => 
                Booking.findOne({ 
                    flight: req.body.flight, 
                    'seats.seatNumber': seat.seatNumber,
                    status: { $ne: 'Cancelled' }
                })
            )
        );
        
        if (seatCheck.some(result => result !== null)) {
            return res.status(400).json({ message: 'One or more seats are already booked' });
        }
        
        // Create booking
        const booking = new Booking({
            passenger: req.body.passenger,
            flight: req.body.flight,
            travelDate: req.body.travelDate,
            ticketDetails: {
                adults: req.body.adults,
                children: req.body.children,
                infants: req.body.infants,
                totalAmount: req.body.totalAmount
            },
            seats: req.body.selectedSeats,
            status: 'Pending' // Admin will confirm later
        });
        
        const savedBooking = await booking.save();
        
        // Update passenger's bookings
        await Passenger.findByIdAndUpdate(
            req.body.passenger,
            { $push: { bookings: savedBooking._id } }
        );
        
        // Update flight's available seats
        await Flight.findByIdAndUpdate(
            req.body.flight,
            { $inc: { availableSeats: -req.body.selectedSeats.length } }
        );
        
        res.status(201).json(savedBooking);
        
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get available seats for a flight
router.get('/:flightId/seats', async (req, res) => {
    try {
        const flight = await Flight.findById(req.params.flightId);
        if (!flight) {
            return res.status(404).json({ message: 'Flight not found' });
        }
        
        // Get all booked seats for this flight
        const bookings = await Booking.find({ 
            flight: req.params.flightId,
            status: { $ne: 'Cancelled' }
        });
        
        const bookedSeats = bookings.flatMap(b => b.seats.map(s => s.seatNumber));
        
        // Generate seat map (simplified - in real app you'd have actual seat configuration)
        const seatMap = [];
        const rows = Math.ceil(flight.capacity / 6);
        
        for (let row = 1; row <= rows; row++) {
            for (let col = 0; col < 6; col++) {
                const seatNumber = `${row}${String.fromCharCode(65 + col)}`;
                seatMap.push({
                    number: seatNumber,
                    status: bookedSeats.includes(seatNumber) ? 'booked' : 'available'
                });
            }
        }
        
        res.json(seatMap);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Other existing routes...

module.exports = router;