// Calculate fare for a flight
router.post('/:id/fare', async (req, res) => {
    try {
        const flight = await Flight.findById(req.params.id);
        if (!flight) {
            return res.status(404).json({ message: 'Flight not found' });
        }
        
        // Simplified fare calculation - in real app you'd have proper pricing logic
        const baseFare = 100; // Base fare per adult
        const adultFare = baseFare * (req.body.adults || 0);
        const childFare = baseFare * 0.75 * (req.body.children || 0);
        const infantFare = baseFare * 0.5 * (req.body.infants || 0);
        
        const totalAmount = adultFare + childFare + infantFare;
        
        res.json({ totalAmount });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});