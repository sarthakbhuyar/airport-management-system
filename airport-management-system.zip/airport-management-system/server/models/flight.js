const mongoose = require('mongoose');

const flightSchema = new mongoose.Schema({
    flightNumber: { type: String, required: true, unique: true },
    airline: { type: String, required: true },
    departureAirport: { type: String, required: true },
    arrivalAirport: { type: String, required: true },
    departureTime: { type: Date, required: true },
    arrivalTime: { type: Date, required: true },
    capacity: { type: Number, required: true },
    availableSeats: { type: Number, required: true },
    status: { type: String, enum: ['scheduled', 'delayed', 'departed', 'arrived', 'cancelled'], default: 'scheduled' }
});

module.exports = mongoose.model('Flight', flightSchema);