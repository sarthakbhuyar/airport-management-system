const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    passenger: { type: mongoose.Schema.Types.ObjectId, ref: 'Passenger', required: true },
    flight: { type: mongoose.Schema.Types.ObjectId, ref: 'Flight', required: true },
    bookingDate: { type: Date, default: Date.now },
    travelDate: { type: Date, required: true },
    ticketDetails: {
        adults: { type: Number, required: true, min: 1 },
        children: { type: Number, default: 0 },
        infants: { type: Number, default: 0 },
        totalAmount: { type: Number, required: true }
    },
    seats: [{
        seatNumber: String,
        passengerName: String,
        passengerAge: Number,
        passengerGender: String
    }],
    status: { 
        type: String, 
        enum: ['Pending', 'Confirmed', 'Cancelled', 'Completed'],
        default: 'Pending'
    },
    paymentStatus: {
        type: String,
        enum: ['Pending', 'Paid', 'Failed', 'Refunded'],
        default: 'Pending'
    },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Booking', bookingSchema);