const mongoose = require('mongoose');

const passengerSchema = new mongoose.Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    age: { type: Number, required: true },
    gender: { type: String, enum: ['Male', 'Female', 'Other'], required: true },
    governmentIdType: { 
        type: String, 
        enum: ['Passport', 'Driver License', 'National ID', 'Other'],
        required: true 
    },
    governmentIdNumber: { type: String, required: true },
    contactNumber: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    address: {
        street: String,
        city: String,
        state: String,
        country: String,
        zipCode: String
    },
    bookings: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Booking' }],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Passenger', passengerSchema);