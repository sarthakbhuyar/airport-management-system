module.exports = {
    DB_URI: 'mongodb://localhost:27017/airportDB' // Replace with your MongoDB URI
    // For MongoDB Atlas: 'mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/airportDB?retryWrites=true&w=majority'
};